//
//  AppDelegate.h
//  TableView_Optimize
//
//  Created by meitianhui2 on 2018/1/4.
//  Copyright © 2018年 DeLongYang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

