//
//  LoginSuccessViewController.h
//  TestDemo
//
//  Created by zhangfei on 16/1/10.
//  Copyright © 2016年 zhangfei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginSuccessViewController : UIViewController

@end
